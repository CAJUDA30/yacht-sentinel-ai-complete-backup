#!/bin/bash
cd /Users/carlosjulia/yacht-sentinel-ai-complete
exec npm run dev
