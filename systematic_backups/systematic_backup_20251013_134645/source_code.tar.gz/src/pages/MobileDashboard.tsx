import MobileDashboard from '@/components/mobile/MobileDashboard';

const MobileDashboardPage = () => {
  return <MobileDashboard />;
};

export default MobileDashboardPage;