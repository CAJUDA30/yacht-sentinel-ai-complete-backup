import SystemCompletionDashboard from '@/components/SystemCompletionDashboard';

const SystemCompletion = () => {
  return <SystemCompletionDashboard />;
};

export default SystemCompletion;