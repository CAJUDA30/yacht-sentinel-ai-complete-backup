import YachtieChat from "@/components/YachtieChat";

const YachtieAI = () => {
  return <YachtieChat />;
};

export default YachtieAI;