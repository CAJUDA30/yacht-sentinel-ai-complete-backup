import AdvancedMobileCamera from '@/components/mobile/AdvancedMobileCamera';

const AdvancedCameraPage = () => {
  return <AdvancedMobileCamera />;
};

export default AdvancedCameraPage;