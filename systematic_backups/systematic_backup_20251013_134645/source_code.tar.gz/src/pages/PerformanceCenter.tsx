import PerformanceOptimizationCenter from '@/components/performance/PerformanceOptimizationCenter';

const PerformanceCenter = () => {
  return <PerformanceOptimizationCenter />;
};

export default PerformanceCenter;