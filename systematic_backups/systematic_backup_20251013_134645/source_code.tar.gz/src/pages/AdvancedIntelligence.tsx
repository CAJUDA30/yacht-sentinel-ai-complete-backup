import AdvancedIntelligenceDashboard from '@/components/AdvancedIntelligenceDashboard';

const AdvancedIntelligence = () => {
  return <AdvancedIntelligenceDashboard />;
};

export default AdvancedIntelligence;