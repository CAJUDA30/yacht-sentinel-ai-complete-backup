import { SmartRecommendationEngine } from '@/components/SmartRecommendationEngine';

const SmartRecommendations = () => {
  return <SmartRecommendationEngine />;
};

export default SmartRecommendations;