import OfflineCapabilityManager from '@/components/offline/OfflineCapabilityManager';

const OfflineManager = () => {
  return <OfflineCapabilityManager />;
};

export default OfflineManager;