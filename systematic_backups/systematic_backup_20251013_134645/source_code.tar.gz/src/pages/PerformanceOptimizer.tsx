import { PerformanceOptimizer } from '@/components/PerformanceOptimizer';

const PerformanceOptimizerPage = () => {
  return <PerformanceOptimizer />;
};

export default PerformanceOptimizerPage;