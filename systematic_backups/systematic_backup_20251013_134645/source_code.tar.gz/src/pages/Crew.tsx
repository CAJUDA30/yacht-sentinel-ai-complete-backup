import CrewAI from "@/components/CrewAI";

const Crew = () => {
  return <CrewAI />;
};

export default Crew;