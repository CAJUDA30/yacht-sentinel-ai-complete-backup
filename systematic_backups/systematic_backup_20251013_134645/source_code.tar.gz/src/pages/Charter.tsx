import CharterAI from "@/components/CharterAI";

const Charter = () => {
  return <CharterAI />;
};

export default Charter;