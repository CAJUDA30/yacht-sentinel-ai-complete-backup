import AdvancedOperationsDashboard from '@/components/AdvancedOperationsDashboard';

const AdvancedOperations = () => {
  return <AdvancedOperationsDashboard />;
};

export default AdvancedOperations;