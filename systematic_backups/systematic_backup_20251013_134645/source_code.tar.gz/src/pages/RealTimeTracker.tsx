import RealTimeTracker from '@/components/mobile/RealTimeTracker';

const RealTimeTrackerPage = () => {
  return <RealTimeTracker />;
};

export default RealTimeTrackerPage;