import SafetyAI from "@/components/SafetyAI";

const Safety = () => {
  return <SafetyAI />;
};

export default Safety;