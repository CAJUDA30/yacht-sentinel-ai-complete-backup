import SystemMonitoringDashboard from '@/components/monitoring/SystemMonitoringDashboard';

const SystemMonitoring = () => {
  return <SystemMonitoringDashboard />;
};

export default SystemMonitoring;