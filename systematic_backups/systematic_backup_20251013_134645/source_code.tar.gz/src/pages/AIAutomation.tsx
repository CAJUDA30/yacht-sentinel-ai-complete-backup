import AIAutomationWorkflows from '@/components/AIAutomationWorkflows';

const AIAutomation = () => {
  return <AIAutomationWorkflows />;
};

export default AIAutomation;