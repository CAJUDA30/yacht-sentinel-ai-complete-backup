import { SmartNotificationCenter } from '@/components/SmartNotificationCenter';

const SmartNotifications = () => {
  return <SmartNotificationCenter />;
};

export default SmartNotifications;