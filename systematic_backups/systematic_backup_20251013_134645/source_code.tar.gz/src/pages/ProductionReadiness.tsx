import { ProductionReadinessDashboard } from '@/components/ProductionReadinessDashboard';

const ProductionReadiness = () => {
  return <ProductionReadinessDashboard />;
};

export default ProductionReadiness;