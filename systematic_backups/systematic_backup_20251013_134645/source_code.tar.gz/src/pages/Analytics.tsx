import ComprehensiveAnalyticsDashboard from '@/components/analytics/ComprehensiveAnalyticsDashboard';

const Analytics = () => {
  return <ComprehensiveAnalyticsDashboard />;
};

export default Analytics;