import AdvancedReportingDashboard from '@/components/reporting/AdvancedReportingDashboard';

const AdvancedReporting = () => {
  return <AdvancedReportingDashboard />;
};

export default AdvancedReporting;