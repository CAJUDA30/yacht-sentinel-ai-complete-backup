import NavigationAI from "@/components/NavigationAI";

const NavigationPage = () => {
  return <NavigationAI />;
};

export default NavigationPage;