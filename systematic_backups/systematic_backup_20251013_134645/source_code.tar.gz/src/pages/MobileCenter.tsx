import EnhancedMobileDashboard from '@/components/mobile/EnhancedMobileDashboard';

const MobileCenter = () => {
  return <EnhancedMobileDashboard />;
};

export default MobileCenter;