import DeploymentDashboard from '@/components/deployment/DeploymentDashboard';

const DeploymentDashboardPage = () => {
  return <DeploymentDashboard />;
};

export default DeploymentDashboardPage;