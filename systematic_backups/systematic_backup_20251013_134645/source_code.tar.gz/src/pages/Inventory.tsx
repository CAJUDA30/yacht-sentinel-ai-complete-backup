import InventoryModule from "@/components/InventoryModule";

const Inventory = () => {
  return <InventoryModule />;
};

export default Inventory;