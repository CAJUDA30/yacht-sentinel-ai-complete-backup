import ComplianceTracker from '@/components/compliance/ComplianceTracker';

const ComplianceTrackerPage = () => {
  return <ComplianceTracker />;
};

export default ComplianceTrackerPage;