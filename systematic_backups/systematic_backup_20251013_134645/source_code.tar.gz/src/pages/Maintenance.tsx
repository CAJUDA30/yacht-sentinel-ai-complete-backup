import MaintenanceModule from "@/components/MaintenanceModule";

const Maintenance = () => {
  return <MaintenanceModule />;
};

export default Maintenance;