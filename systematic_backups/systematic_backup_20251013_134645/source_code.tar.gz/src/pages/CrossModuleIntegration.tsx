import CrossModuleIntegrationDashboard from '@/components/CrossModuleIntegrationDashboard';

const CrossModuleIntegration = () => {
  return <CrossModuleIntegrationDashboard />;
};

export default CrossModuleIntegration;