import SystemIntegrationHub from '@/components/integration/SystemIntegrationHub';

const IntegrationHub = () => {
  return <SystemIntegrationHub />;
};

export default IntegrationHub;