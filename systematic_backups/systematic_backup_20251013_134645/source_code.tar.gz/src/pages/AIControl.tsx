import AIControlCenter from '@/components/AIControlCenter';

const AIControl = () => {
  return <AIControlCenter />;
};

export default AIControl;