import AdvancedSecurityDashboard from '@/components/security/AdvancedSecurityDashboard';

const SecurityDashboard = () => {
  return <AdvancedSecurityDashboard />;
};

export default SecurityDashboard;