import DocumentProcessingDashboard from "@/components/admin/DocumentProcessingDashboard";

const DocumentProcessingPage = () => {
  return <DocumentProcessingDashboard />;
};

export default DocumentProcessingPage;