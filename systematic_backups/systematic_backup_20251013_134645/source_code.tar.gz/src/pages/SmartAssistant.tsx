import SmartYachtAssistant from '@/components/SmartYachtAssistant';

const SmartAssistant = () => {
  return <SmartYachtAssistant />;
};

export default SmartAssistant;