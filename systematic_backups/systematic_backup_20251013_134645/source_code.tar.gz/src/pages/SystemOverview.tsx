import ComprehensiveSystemDashboard from '@/components/system/ComprehensiveSystemDashboard';

const SystemOverview = () => {
  return <ComprehensiveSystemDashboard />;
};

export default SystemOverview;