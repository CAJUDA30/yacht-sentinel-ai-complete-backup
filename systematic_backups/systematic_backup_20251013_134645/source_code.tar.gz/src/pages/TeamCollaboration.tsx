import TeamCollaborationHub from '@/components/collaboration/TeamCollaborationHub';

const TeamCollaboration = () => {
  return <TeamCollaborationHub />;
};

export default TeamCollaboration;