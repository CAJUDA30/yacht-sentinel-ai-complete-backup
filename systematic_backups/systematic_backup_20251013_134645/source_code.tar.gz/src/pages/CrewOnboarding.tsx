import CrewOnboardingDashboard from "@/components/CrewOnboardingDashboard";

const CrewOnboarding = () => {
  return <CrewOnboardingDashboard />;
};

export default CrewOnboarding;