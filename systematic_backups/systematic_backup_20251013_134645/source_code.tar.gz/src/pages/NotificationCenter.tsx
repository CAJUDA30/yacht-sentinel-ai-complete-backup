import RealTimeNotificationCenter from '@/components/realtime/RealTimeNotificationCenter';

const NotificationCenter = () => {
  return <RealTimeNotificationCenter />;
};

export default NotificationCenter;