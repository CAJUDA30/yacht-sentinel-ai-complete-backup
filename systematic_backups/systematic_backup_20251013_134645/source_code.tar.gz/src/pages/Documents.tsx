import DocumentsAI from "@/components/DocumentsAI";

const Documents = () => {
  return <DocumentsAI />;
};

export default Documents;